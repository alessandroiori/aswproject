### Description

Place here a short description about what is happening.

### Steps to reproduce

Place here some steps how to reproduce the bug (some puppet code would be great, too)

### Expected behavior

Here should be the behavior you've expected

### Further details

In order to figure out what's happening information like your OS, the OS Version, the version of this module, the Puppet and Facter version.
When using Vagrant, then its version, too.
Information about other puppet modules and their version might be also helpful.

### Related issues

If you're aware of other issues or even issues in other libraries being used by this package then you should reference them here as they may help to solve the issue.
