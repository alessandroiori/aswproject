require 'rubygems'
require 'puppetlabs_spec_helper/module_spec_helper'
require 'rspec'

$:.unshift File.join(File.dirname(__FILE__),  'fixtures', 'modules', 'stdlib', 'lib')
